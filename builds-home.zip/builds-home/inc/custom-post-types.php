<?php
/**
 * カスタム投稿タイプ・タクソノミー登録
 */

function builds_home_register_post_types() {
    // 物件 CPT
    register_post_type('property', [
        'labels' => [
            'name'          => '物件',
            'singular_name' => '物件',
            'add_new'       => '物件を新規登録',
            'add_new_item'  => '物件を新規登録',
            'edit_item'     => '物件を編集',
            'new_item'      => '新しい物件',
            'view_item'     => '物件を表示',
            'search_items'  => '物件を検索',
            'not_found'     => '物件が見つかりません',
            'menu_name'     => '物件管理',
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => ['slug' => 'property'],
        'supports'     => ['title', 'editor', 'thumbnail'],
        'menu_icon'    => 'dashicons-building',
        'show_in_rest' => true,
        'menu_position' => 5,
    ]);

    // お知らせ CPT
    register_post_type('news', [
        'labels' => [
            'name'          => 'お知らせ',
            'singular_name' => 'お知らせ',
            'add_new'       => 'お知らせを追加',
            'add_new_item'  => 'お知らせを追加',
            'edit_item'     => 'お知らせを編集',
            'menu_name'     => 'お知らせ',
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => ['slug' => 'news'],
        'supports'     => ['title', 'editor', 'thumbnail'],
        'menu_icon'    => 'dashicons-megaphone',
        'show_in_rest' => true,
        'menu_position' => 6,
    ]);

    // お知らせカテゴリー
    register_taxonomy('news_category', 'news', [
        'labels' => [
            'name'          => 'お知らせカテゴリー',
            'singular_name' => 'カテゴリー',
            'menu_name'     => 'カテゴリー',
        ],
        'hierarchical' => true,
        'rewrite'      => ['slug' => 'news-category'],
        'show_in_rest' => true,
    ]);

    // 物件種別タクソノミー
    register_taxonomy('property_type', 'property', [
        'labels' => [
            'name'          => '物件種別',
            'singular_name' => '物件種別',
            'add_new_item'  => '物件種別を追加',
            'menu_name'     => '物件種別',
        ],
        'hierarchical' => true,
        'rewrite'      => ['slug' => 'property-type'],
        'show_in_rest' => true,
    ]);

    // お客様の声 CPT
    register_post_type('voice', [
        'labels' => [
            'name'          => 'お客様の声',
            'singular_name' => 'お客様の声',
            'add_new'       => '声を追加',
            'add_new_item'  => 'お客様の声を追加',
            'edit_item'     => 'お客様の声を編集',
            'menu_name'     => 'お客様の声',
        ],
        'public'       => false,
        'show_ui'      => true,
        'supports'     => ['title', 'editor'],
        'menu_icon'    => 'dashicons-format-quote',
        'show_in_rest' => true,
        'menu_position' => 7,
    ]);

    // エリアタクソノミー
    register_taxonomy('property_area', 'property', [
        'labels' => [
            'name'          => 'エリア',
            'singular_name' => 'エリア',
            'add_new_item'  => 'エリアを追加',
            'menu_name'     => 'エリア',
        ],
        'hierarchical' => true,
        'rewrite'      => ['slug' => 'area'],
        'show_in_rest' => true,
    ]);
}
add_action('init', 'builds_home_register_post_types');

// 初期タームの登録
function builds_home_register_default_terms() {
    // 物件種別
    $property_types = [
        '中古マンション', '中古戸建', '新築戸建', '新築マンション',
        '土地', '収益物件', '事業用',
    ];
    foreach ($property_types as $term) {
        if (!term_exists($term, 'property_type')) {
            wp_insert_term($term, 'property_type');
        }
    }

    // エリア
    $areas = [
        '川崎市多摩区', '川崎市高津区', '川崎市宮前区',
        '川崎市麻生区', '稲城市', '調布市',
    ];
    foreach ($areas as $term) {
        if (!term_exists($term, 'property_area')) {
            wp_insert_term($term, 'property_area');
        }
    }
}
add_action('init', 'builds_home_register_default_terms');
